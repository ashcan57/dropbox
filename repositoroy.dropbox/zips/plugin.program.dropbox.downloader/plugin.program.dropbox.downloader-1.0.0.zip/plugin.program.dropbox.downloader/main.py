import xbmc
import xbmcgui
import xbmcvfs
import urllib.request

# --- HARDCODE YOUR LINK AND FILENAME HERE ---
# IMPORTANT: Make sure your Dropbox link ends in ?dl=1 for a direct download.
DROPBOX_URL = "https://www.dropbox.com/scl/fi/90rsb9oal9dc3fp3g1l8s/dab19.zip?rlkey=5st59x4bq5xpvljnf0rlflu1z&st=2xmbpgy3&dl=1"
FILE_NAME = "dab19.zip"
# -----------------------------------------

def download_build():
    """Downloads the file from the hardcoded Dropbox URL."""
    # Check if the URL has been changed from the default
    if not DROPBOX_URL or "YOUR_DROPBOX_DIRECT_LINK_HERE" in DROPBOX_URL:
        xbmcgui.Dialog().ok("Error", "Dropbox URL is not set.", "Please edit main.py to add your direct download link.")
        return

    # Get a safe, writable path in Kodi's home directory
    dest_path = xbmcvfs.translatePath('special://home')
    dest_file = dest_path + FILE_NAME

    # Setup the progress dialog that the user will see
    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create('Build Downloader', 'Initializing download...')

    try:
        # Use Python's urllib to download the file
        urllib.request.urlretrieve(DROPBOX_URL, dest_file)

        p_dialog.close()
        xbmcgui.Dialog().ok("Success", f"File downloaded successfully!")

    except Exception as e:
        p_dialog.close()
        xbmcgui.Dialog().ok("Download Failed", f"An error occurred: {str(e)}")

def report_hook(p_dialog, block_num, block_size, total_size):
    """Callback function to update the progress dialog."""
    downloaded = block_num * block_size
    percent = int(downloaded * 100 / total_size) if total_size > 0 else 0

    if p_dialog.iscanceled():
        raise Exception("Download canceled by user.")

    p_dialog.update(percent, f"Downloaded {percent}%", f"{downloaded // 1024 // 1024}MB of {total_size // 1024 // 1024}MB")

if __name__ == '__main__':
    download_build()
